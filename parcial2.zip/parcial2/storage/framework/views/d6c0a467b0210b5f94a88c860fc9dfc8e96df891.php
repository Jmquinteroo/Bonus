<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="top-right links">

                                <a href="<?php echo e(route('registro')); ?>">registrar vehiculo</a>
                                <a href="<?php echo e(route('lista')); ?>">listar vehiculos</a>
                                <a href="<?php echo e(route('estadisticas')); ?>">estadisticas</a>


                        </div>


                </div>
            </div>



            <div class="col-12">

                <?php if(isset($vehiculo)): ?>
                    <table class="table table-bordered">

                        <tr>

                            <td><b>marca</b></td>

                            <td><b>placa</b></td>


                        </tr>


                        <?php $__currentLoopData = $vehiculo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
<?php if($vehi->marca=='mazda'): ?>
                                <td> <?php echo e($vehi->marca); ?></td>

                                <td><?php echo e($vehi->placa); ?><td bgcolor="green"> Los mazdas son los mejores </td></td>
    <?php else: ?>
                                    <?php if($vehi->marca=='toyota'): ?>
                                        <td> <?php echo e($vehi->marca); ?></td>

                                        <td bgcolor="red"><b><?php echo e($vehi->placa); ?></b></td>
                                    <?php else: ?>
                                        <td> <?php echo e($vehi->marca); ?></td>

                                        <td><?php echo e($vehi->placa); ?></td>
                                    <?php endif; ?>
<?php endif; ?>







                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                <?php endif; ?>









            <?php if(isset($cantidadmazda)): ?>
                    <table class="table table-bordered">

                        <tr>

                            <td>mazda</td>

                            <td>toyota</td>

                            <td>chevrolet</td>

                        </tr>


                            <tr>

                                <td> <?php echo e($cantidadmazda); ?></td>

                                <td><?php echo e($cantidadtoyota); ?></td>

                                <td><?php echo e($cantidad3); ?></td>

                            </tr>


                    </table>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/parcial2/resources/views/zonainicio.blade.php ENDPATH**/ ?>