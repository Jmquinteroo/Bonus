
# Bonus
Para iniciar con la aplicacion despues de bajarla y hubicarse en la carpeta se abre una terminal y se tiran los comandos
composser install
php artisan migrate:fresh --seed
php artisan serve

Una vez abierta la pagina como lo peda el trabajo solo se podra acceder a la zona de inicio añadiendo a la url principal la el codigo "A765" en caso de agregar cualquier codigo distinto a este se muestra un error.
Dentro de la zona de inicio habran 3 link para cada una de las tareas(Registro, listado y estadisticas)
